const express = require("express");
const { receiveMessageOnPort } = require("worker_threads");
const router = express.Router();
const Pizza = require("../models/pizzaModel");
router.get("/getAllPizzas", async (req, res) => {
  try {
    const pizzas = await Pizza.find({});
    res.send(pizzas);
  } catch (error) {
    res.status(400).json({ message: error });
  }
});

module.exports = router;
