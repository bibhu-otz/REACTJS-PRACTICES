const express = require("express");
const db = require("./db");
const pizzas = require("./models/pizzaModel");
const app = express();
const pizzasRoute = require("./routes/pizzasRoute");
app.use(express.json());

app.use("/api/pizzas/", pizzasRoute);
app.get("/", (req, res) => {
  res.send("Server Working !!");
});

app.get("/getpizzas", (req, res) => {
  pizzas
    .find()
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      console.error(err);
    });
});
const port = process.env.PORT || 5000;

app.listen(port, () => "Server running on the port {port}");
