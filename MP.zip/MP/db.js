const mongoose = require("mongoose");

var mongoURL =
  "mongodb+srv://bibmhnt:hele3X41mewHYnCm@cluster0.amddjlu.mongodb.net/mern-pizza";

mongoose.connect(mongoURL, { useUnifiedTopology: true, useNewUrlParser: true });

var db = mongoose.connection;

db.on("connected", () => {
  console.log("Mongo Db Connection Successful");
});

db.on("error", () => {
  console.log("Mongo Db connection failed");
});

module.exports = mongoose;
