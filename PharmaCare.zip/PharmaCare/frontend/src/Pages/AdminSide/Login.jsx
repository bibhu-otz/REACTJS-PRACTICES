export default function AdminLogin() {
  return (
    <div className="AdminLogin">
      <h1>Admin-Login Page</h1>
    </div>
  );
}
