import DoctorComponent1 from "../../Components/UserSide/DoctorComponent1";
import Information from "../../Components/UserSide/Information";
export default function ConsultDoctor() {
  return (
    <div className="ConsultDoctor">
      <DoctorComponent1 />
      <Information />
    </div>
  );
}
