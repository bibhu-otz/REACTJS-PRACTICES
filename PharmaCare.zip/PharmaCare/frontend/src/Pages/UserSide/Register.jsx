import RegisterComponent from "../../Components/UserSide/RegisterComponent";
const Register = () => {
  return (
    <div>
      <RegisterComponent />
    </div>
  );
};

export default Register;
