export default function HoErrorme() {
  return (
    <div className="Error">
      <h1>Erro 404 Not found</h1>
    </div>
  );
}
