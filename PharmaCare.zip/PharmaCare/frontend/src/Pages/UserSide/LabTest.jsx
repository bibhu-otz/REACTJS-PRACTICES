export default function LabTest() {
  return (
    <div className="LabTest">
      <h1>LabTest Page</h1>
    </div>
  );
}
