import MedicineList from "../../Components/UserSide/MedicineList";
export default function Medicines() {
  return (
    <div className="Medicines">
       <MedicineList/>
    </div>
  );
}
