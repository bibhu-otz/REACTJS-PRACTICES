export default function Discover() {
  return (
    <div className="Discover">
      <h1>Discover Page</h1>
    </div>
  );
}
