export default function AdminNavbar() {
  return (
    <div className="AdminNavbar">
      <h1>Admin-Navbar component</h1>
    </div>
  );
}
