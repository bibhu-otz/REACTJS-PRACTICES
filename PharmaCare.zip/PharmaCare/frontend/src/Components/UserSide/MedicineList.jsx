import React from "react";
import { shallowEqual, useDispatch, useSelector } from "react-redux";
import { getMedicines } from "../../Redux/UserSide/Medicine Redux/action";
import MedicineCard from "./MedicineCard";
import "../Styles/UserSide/productlist.css";
const MedicineList = ({ page, limit }) => {
  const dispatch = useDispatch();
 

  const { loading, error, data } = useSelector((store) => {
    return {
      loading: store.MedicineReducer.isLoading,
      data: store.MedicineReducer.medicines,
      error: store.MedicineReducer.isError,
    };
  }, shallowEqual);
  dispatch(getMedicines());
  console.log(data);
  console.log(loading);
  console.log(error);
  return (
    <div className="product_main">
      {loading && (
        <div style={{display:"flex",alignItems:"center"}}>
          <div className="loading"></div> <h1 style={{ textAlign: "center" }}>...Loading</h1>
        </div>
      )}
      {error && <h1 style={{ textAlign: "center" }}>...Error</h1>}

      {data &&
        data.map((el) => {
          return <MedicineCard key={el.id} {...el} />;
        })}
    </div>
  );
};

export default MedicineList;
