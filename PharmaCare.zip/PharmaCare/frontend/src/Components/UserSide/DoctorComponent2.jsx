import React from "react";

function DoctorComponent2({ name }) {
  return <p>{name}</p>;
}

export default DoctorComponent2;
