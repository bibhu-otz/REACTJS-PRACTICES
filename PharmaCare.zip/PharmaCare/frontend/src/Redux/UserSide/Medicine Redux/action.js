import {
  GET_MEDICINE_FAILURE,
  GET_MEDICINE_REQUEST,
  GET_MEDICINE_SUCCESS,
  GET_TOTAL_COUNT,
} from "./actionTypes";
import axios from "axios";
export const getMedicineRequest = () => {
  return { type: GET_MEDICINE_REQUEST };
};

export const getMedicineSuccess = (payload) => {
  return { type: GET_MEDICINE_SUCCESS, payload };
};

export const getMedicineFailure = () => {
  return { type: GET_MEDICINE_FAILURE };
};

export const getTotalCount = (payload) => {
  return { type: GET_TOTAL_COUNT, payload };
};
export const getMedicines = () => (dispatch) => {
  dispatch(getMedicineRequest());
  axios
    .get("http://localhost:2023/medi/")
    .then((res) => {
      dispatch(getTotalCount(Number(res.headers["x-total-count"])));
      dispatch(getMedicineSuccess(res.data));
    })
    .catch((err) => {
      dispatch(getMedicineFailure());
    });
};
