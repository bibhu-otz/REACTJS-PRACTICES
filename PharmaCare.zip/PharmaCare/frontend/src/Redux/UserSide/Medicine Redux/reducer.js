import {
  GET_MEDICINE_FAILURE,
  GET_MEDICINE_REQUEST,
  GET_MEDICINE_SUCCESS,
  GET_TOTAL_COUNT,
} from "./actionTypes";

const initialState = {
  isLoading: false,
  medicines: [],
  isError: false,
  totalCount: 0,
};
export const reducer = (state = initialState, { type, payload }) => {
  switch (type) {
    case GET_MEDICINE_REQUEST: {
      return { ...state, isLoading: false };
    }
    case GET_MEDICINE_SUCCESS: {
      return { ...state, medicines: payload, isLoading: false };
    }
    case GET_MEDICINE_FAILURE: {
      return { ...state, isLoading: false, isError: true };
    }
    case GET_TOTAL_COUNT: {
      return { ...state, totalCount: payload };
    }
    default:
      return state;
  }
};
