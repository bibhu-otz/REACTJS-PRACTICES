const mongoose = require("mongoose");

// Define the vendor schema
const vendorSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: true,
  },
  address: {
    street: String,
    city: String,
    state: String,
    postalCode: String,
    country: String,
  },
  businessname: {
    type: String,
    required: true,
  },
  rating: {
    type: Number,
    default: 0,
  },
  menu: [
    {
      foodItemId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "FoodItem",
      },
      price: Number,
    },
  ],
});

// Create the Vendor model
const Vendor = mongoose.model("Vendor", vendorSchema);

module.exports = Vendor;
