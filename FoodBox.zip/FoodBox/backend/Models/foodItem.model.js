const mongoose = require("mongoose");

// Define the food item schema
const foodItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  description: String,
  price: {
    type: Number,
    required: true,
  },
  categoryId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Category",
    required: true,
  },
});

// Create the FoodItem model
const FoodItem = mongoose.model("FoodItem", foodItemSchema);

module.exports = FoodItem;
