const mongoose = require("mongoose");

const userschema = mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    password: {
      type: String,
      required: true,
    },
    phone: {
      type: String,
      required: true,
    },
    address: {
      street: {
        type: String,
      },
      city: {
        type: String,
      },
      state: {
        type: String,
      },
      postalCode: {
        type: String,
      },
      country: {
        type: String,
      },
    },
    emailVerified: {
      type: Boolean,
    },
  },
  {
    timestamps: true,
  },
  {
    versionKey: false,
  }
);
// Create the User model
const authModel = mongoose.model("user", userschema);
module.exports = { authModel };
