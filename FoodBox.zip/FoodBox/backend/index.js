const express = require("express");
const { connection } = require("./Config/db");
// const { productRouter } = require("./Routes/Product.route");
const { authRouter } = require("./Routes/auth.route");
const cors = require("cors");
const app = express();
app.use(express.json());
require("dotenv").config();
app.use(express.json());
app.use(cors());

//CRUD Operation (consulttRoute)
// app.use("/offers", productRouter);
app.use("/user", authRouter);
app.listen(process.env.port, async () => {
  try {
    await connection;
    console.log("database connected");
  } catch (error) {
    console.log(error);
  }
  console.log(`server is running on port ${process.env.port} `);
});
