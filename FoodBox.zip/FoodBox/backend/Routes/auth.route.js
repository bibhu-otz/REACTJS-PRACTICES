const express = require("express");
const { authModel } = require("../Models/auth.model");
const authRouter = express.Router();
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
//CREATE
authRouter.post("/register", async (req, res) => {
  try {
    console.log(req.body);
    const { name, email, phone, password } = req.body;
    // Check if user already exists
    const existingUser = await authModel.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user instance
    const newUser = new authModel({
      name,
      email,
      phone,
      password: hashedPassword,
    });

    await newUser.save();
    res.status(200).send({ msg: "User registered successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: error.message });
  }
});

//READ
authRouter.get("/getalluser", async (req, res) => {
  try {
    const user = await authModel.find();
    res.status(200).send(user);
  } catch (error) {
    res.status(400).send({ msg: error.message });
  }
});

//DELETE
authRouter.delete("/:id", async (req, res) => {
  try {
    const idExist = await authModel.findOne({ _id: req.params.id });
    if (idExist) {
      await authModel.findByIdAndDelete(req.params.id);
      res.status(200).send({ msg: "user deleted successfully" });
    } else {
      res.status(400).send({ msg: "user id invalid" });
    }
  } catch (error) {
    res.status(400).send({ msg: error.message });
  }
});

//UPDATE
authRouter.patch("/:id", async (req, res) => {
  try {
    const idExist = await authModel.findOne({ _id: req.params.id });
    if (idExist) {
      await authModel.findByIdAndUpdate(req.params.id, req.body);
      res.status(200).send({ msg: "user updated successfully" });
    } else {
      res.status(400).send({ msg: "user id invalid" });
    }
  } catch (error) {
    res.status(400).send({ msg: error.message });
  }
});

//GET BY ID
authRouter.get("/search/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const user = await authModel.findOne({ _id: id });
    res.status(200).send(user);
  } catch (error) {
    res.status(400).send({ msg: error });
  }
});

authRouter.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    // Check if user exists
    const user = await authModel.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // Compare passwords
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // Generate a JWT token
    const token = jwt.sign({ userId: user._id }, "your-secret-key", {
      expiresIn: "1h",
    });
    res.json({ token });
    // res.status(200).send(user);
  } catch (error) {
    console.error(error);
    res.status(500).send({ msg: error });
  }
});

module.exports = { authRouter };
