import  "./assets/css/bootstrap-extended.css"
import  "./assets/css/bootstrap.min.css"
import  ".assets/css/bootstrap-extended.css"
import  "./assets/css/style.css"
import  "./assets/css/icons.css"
import  "./assets/css/pace.min.css"
import  "./assets/css/dark-theme.css"
import  "./assets/css/pace.min.css"
import  "./assets/css/dark-theme.css"
import  "./assets/css/semi-dark.css"
import  "./assets/css/header-colors.css"
import  "./assets/js/bootstrap.bundle.min.js"
import  "./assets/js/jquery.min.js"
import  "./assets/plugins/simplebar/js/simplebar.min.js"
import  "./assets/plugins/metismenu/js/metisMenu.min.js"
import  "./assets/plugins/easyPieChart/jquery.easypiechart.js"
import  "./assets/plugins/peity/jquery.peity.min.js"
import  "./assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"
import  "./assets/js/pace.min.js"
import  "./assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"
import  "./assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"
import  "./assets/plugins/apexcharts-bundle/js/apexcharts.min.js"
import  "./assets/plugins/datatable/js/jquery.dataTables.min.js"
import  "./assets/plugins/datatable/js/dataTables.bootstrap5.min.js"
import  "./assets/js/app.js"
import  "./assets/js/index.js"

 
  
 

  