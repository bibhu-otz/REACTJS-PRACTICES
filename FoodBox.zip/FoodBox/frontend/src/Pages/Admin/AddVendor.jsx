export default function Addvendor(){
    return(
        <div className="wrapper">
            <main className="page-content">
             <div className="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
               <div className="breadcrumb-title pe-3">Admin</div>
               <div className="ps-3">
                 <nav aria-label="breadcrumb">
                   <ol className="breadcrumb mb-0 p-0">
                     <li className="breadcrumb-item"><a href="javascript:;"><i className="bx bx-home-alt"></i></a>
                     </li>
                     <li className="breadcrumb-item active" aria-current="page">Add New Admin</li>
                   </ol>
                 </nav>
               </div>
              
             </div>
            
 
               <div className="row">
                  <div className="col-lg-8 mx-auto">
                   <div className="card">
                     <div className="card-header py-3 bg-transparent"> 
                        <h5 className="mb-0">Add Vendor</h5>
                       </div>
                     <div className="card-body" id="formAdmin">
                       <div   className="border p-3 rounded">
                       <form className="row g-3"  id="myform" method="post"  enctype="multipart/form-data" >
                         <div className="col-12">
                           <label className="form-label">Hotel Name</label>
                           <input type="text" name="name" className="form-control" placeholder="Enter Name" required/>
                           <input type="hidden" name="event" value=""/>
                         </div>
                         <div className="col-12">
                           <label className="form-label">Description</label>
                         <input type="textarea" className="form-control" name="email" placeholder="Enter Email" required/>
                         </div>
                         <div className="col-12">
                           <label className="form-label">Hotel Address</label>
                         <input type="password" className="form-control"  name="password"placeholder="Enter Password" required/>
                         </div>
                         <div className="col-12">
                            <select name="city" className="form-control" id="">
                                <option>Choose City</option>
                                <option>bbsr</option>
                                <option>ctc</option>
                                <option>bdk</option>
                            </select>
                         </div>
                         
                         <div className="col-12">
                           <label className="form-label">Hotel Images</label>
                           <input type="file" className="form-control" name="image" required/>
                         </div>
                         
                         <div className="col-12">
                           <input type="submit" className="btn btn-primary px-4"  id="submit" value="Add Admin"/>
                         </div>
                       </form>
                       </div>
                      </div>
                     </div>
                  </div>
               </div>
 
           </main>
        
         <div className="overlay nav-toggle-icon"></div>
        
         <a href="javaScript:;" className="back-to-top"><i className='bx bxs-up-arrow-alt'></i></a>
         
         
         
        <div className="switcher-body">
         <button className="btn btn-primary btn-switcher shadow-sm" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling"><i className="bi bi-paint-bucket me-0"></i></button>
         <div className="offcanvas offcanvas-end shadow border-start-0 p-2" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling">
           <div className="offcanvas-header border-bottom">
             <h5 className="offcanvas-title" id="offcanvasScrollingLabel">Theme Customizer</h5>
             <button type="button" className="btn-close text-reset" data-bs-dismiss="offcanvas"></button>
           </div>
           <div className="offcanvas-body">
             <h6 className="mb-0">Theme Variation</h6>
             <hr/>
             <div className="form-check form-check-inline">
               <input className="form-check-input" type="radio" name="inlineRadioOptions" id="LightTheme" value="option1"/>
               <label className="form-check-label" for="LightTheme">Light</label>
             </div>
             <div className="form-check form-check-inline">
               <input className="form-check-input" type="radio" name="inlineRadioOptions" id="DarkTheme" value="option2"/>
               <label className="form-check-label" for="DarkTheme">Dark</label>
             </div>
             <div className="form-check form-check-inline">
               <input className="form-check-input" type="radio" name="inlineRadioOptions" id="SemiDarkTheme" value="option3"/>
               <label className="form-check-label" for="SemiDarkTheme">Semi Dark</label>
             </div>
             <hr/>
             <div className="form-check form-check-inline">
               <input className="form-check-input" type="radio" name="inlineRadioOptions" id="MinimalTheme" value="option3" checked/>
               <label className="form-check-label" for="MinimalTheme">Minimal Theme</label>
             </div>
             <hr/>
             <h6 className="mb-0">Header Colors</h6>
             <hr/>
             <div className="header-colors-indigators">
               <div className="row row-cols-auto g-3">
                 <div className="col">
                   <div className="indigator headercolor1" id="headercolor1"></div>
                 </div>
                 <div className="col">
                   <div className="indigator headercolor2" id="headercolor2"></div>
                 </div>
                 <div className="col">
                   <div className="indigator headercolor3" id="headercolor3"></div>
                 </div>
                 <div className="col">
                   <div className="indigator headercolor4" id="headercolor4"></div>
                 </div>
                 <div className="col">
                   <div className="indigator headercolor5" id="headercolor5"></div>
                 </div>
                 <div className="col">
                   <div className="indigator headercolor6" id="headercolor6"></div>
                 </div>
                 <div className="col">
                   <div className="indigator headercolor7" id="headercolor7"></div>
                 </div>
                 <div className="col">
                   <div className="indigator headercolor8" id="headercolor8"></div>
                 </div>
               </div>
             </div>
           </div>
         </div>
        </div>
       
 
   </div>
    );
}