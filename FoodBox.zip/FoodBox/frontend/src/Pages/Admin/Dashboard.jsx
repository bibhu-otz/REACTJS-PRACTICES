


export default function Dasbboard() {
    return (
        <>
            <h1 className="mt-5">Admin Dashboard</h1>
        </>
    );
}




