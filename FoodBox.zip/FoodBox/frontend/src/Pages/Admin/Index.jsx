import Header from "../../Components/Admin/Header";
import Sidebar from "../../Components/Admin/Sidebar";
import Dashboard from "./Dashboard";

export default function Index(){
    return(
        <>
        <Header/>
        <Sidebar/>
        <Dashboard/>
        </>
    );
}