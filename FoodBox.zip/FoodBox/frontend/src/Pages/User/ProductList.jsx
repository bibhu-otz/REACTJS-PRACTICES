import Img1 from '../../Components/Images/item_Images/1.jpg'
export default function ProductList() {
    return(
        <>
        <div className="shop-page-wrapper shop-page-padding ptb-100 mt-5">
          <div className="container-fluid">
            <div className="row gy-5">
                <div className="col-lg-3 order-2 order-lg-1">
                    <div className="shop-sidebar mr-50">
                        <div className="sidebar-widget mb-50">
                            <h3 className="sidebar-title">Search Products</h3>
                            <div className="sidebar-search">
                                <form action="#">
                                    <input placeholder="Search Products..." type="text"/>
                                    <button><i className="ti-search"></i></button>
                                </form>
                            </div>
                        </div>
                       
                        <div className="sidebar-widget mb-45">
                            <h3 className="sidebar-title">Categories</h3>
                            <div className="sidebar-categories">
                                <ul id="view_Category">
                                    <li><a href="a">Category1</a></li>
                                    <li><a href="a">Category2</a></li>
                                    <li><a href="a">Category3</a></li>
                                    <li><a href="a">Category4</a></li>
                                </ul>
                            </div>
                        </div>
                     </div>
                </div>
                <div className="col-lg-9 order-1 order-lg-2">
                    <div className="shop-product-wrapper res-xl">
                        <div className="shop-bar-area">
                            
                            <div className="shop-product-content tab-content">
                                <div id="grid-sidebar11" className="tab-pane fade">
                                    <div className="row">
                                        
                                    </div>
                                </div>
                                <div id="grid-sidebar12" className="tab-pane fade active show">
                                    <div className="row" id="items">  
                                                                            
                                        <div className="col-md-6 col-xl-6">
                                             
                                            <div className="product-wrapper mb-30 single-product-list product-list-right-pr mb-60">
                                                <div className="product-img list-img-width">
                                                    <a href="a">
                                                    <img src={Img1} alt=""/>
                                                    </a>
                                                    <span>hot</span>
                                                    <div className="product-action-list-style">
                                                     
                                                    </div>
                                                </div>
                                                <div className="product-content-list">
                                                <div className="product-list-info">
                                                     <h4><a href="a">Fish Curry</a></h4>
                                                     <span>$124</span>
                                                     <p>description about fish </p></div>
                                                     <div className="product-list-cart-wishlist">  
                                                     <div className="product-list-cart">
                                                     <a className="btn-hover list-btn-style"  onclick='openModal(this.id)' href="a">add to cart</a>
                                                     </div>
                                                     <div className="product-list-wishlist">
                                                     <a className="btn-hover list-btn-wishlist" href="a"><i className="pe-7s-like"></i></a>
                                               </div></div></div>
                                            </div>
                                            
                                            
                                        </div>
                                        <div className="col-md-6 col-xl-6">
                                             
                                             <div className="product-wrapper mb-30 single-product-list product-list-right-pr mb-60">
                                                 <div className="product-img list-img-width">
                                                     <a href="a">
                                                     <img src={Img1} alt=""/>
                                                     </a>
                                                     <span>hot</span>
                                                     <div className="product-action-list-style">
                                                      
                                                     </div>
                                                 </div>
                                                 <div className="product-content-list">
                                                 <div className="product-list-info">
                                                      <h4><a href="a">Fish Curry</a></h4>
                                                      <span>$124</span>
                                                      <p>description about fish </p></div>
                                                      <div className="product-list-cart-wishlist">  
                                                      <div className="product-list-cart">
                                                      <a className="btn-hover list-btn-style"  onclick='openModal(this.id)' href="a">add to cart</a>
                                                      </div>
                                                      <div className="product-list-wishlist">
                                                      <a className="btn-hover list-btn-wishlist" href=""><i className="pe-7s-like"></i></a>
                                                </div></div></div>
                                             </div>
                                             
                                             
                                         </div>
                                         <div className="col-md-6 col-xl-6">
                                             
                                             <div className="product-wrapper mb-30 single-product-list product-list-right-pr mb-60">
                                                 <div className="product-img list-img-width">
                                                     <a href="a">
                                                     <img src={Img1} alt=""/>
                                                     </a>
                                                     <span>hot</span>
                                                     <div className="product-action-list-style">
                                                      
                                                     </div>
                                                 </div>
                                                 <div className="product-content-list">
                                                 <div className="product-list-info">
                                                      <h4><a href="a">Fish Curry</a></h4>
                                                      <span>$124</span>
                                                      <p>description about fish </p></div>
                                                      <div className="product-list-cart-wishlist">  
                                                      <div className="product-list-cart">
                                                      <a className="btn-hover list-btn-style"  onclick='openModal(this.id)' href="a" data-toggle="modal" data-target="#modal1">add to cart</a>
                                                      </div>
                                                      <div className="product-list-wishlist">
                                                      <a className="btn-hover list-btn-wishlist" href="a"><i className="pe-7s-like"></i></a>
                                                </div></div></div>
                                             </div>
                                             
                                             
                                         </div>
                                         <div className="col-md-6 col-xl-6">
                                              
                                              <div className="product-wrapper mb-30 single-product-list product-list-right-pr mb-60">
                                                  <div className="product-img list-img-width">
                                                      <a href="a">
                                                      <img src={Img1} alt=""/>
                                                      </a>
                                                      <span>hot</span>
                                                      <div className="product-action-list-style">
                                                       
                                                      </div>
                                                  </div>
                                                  <div className="product-content-list">
                                                  <div className="product-list-info">
                                                       <h4><a href="a">Fish Curry</a></h4>
                                                       <span>$124</span>
                                                       <p>description about fish </p></div>
                                                       <div className="product-list-cart-wishlist">  
                                                       <div className="product-list-cart">
                                                       <a className="btn-hover list-btn-style"  onclick='openModal(this.id)' href="a">add to cart</a>
                                                       </div>
                                                       <div className="product-list-wishlist">
                                                       <a className="btn-hover list-btn-wishlist" href=""><i className="pe-7s-like"></i></a>
                                                 </div></div></div>
                                              </div>
                                              
                                              
                                          </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="pagination-style mt-10 text-center">
                        <ul>
                            <li><a href="a"><i className="ti-angle-left"></i></a></li>
                            <li><a href="a">1</a></li>
                            <li><a href="a">2</a></li>
                            <li><a href="a">...</a></li>
                            <li><a href="a">19</a></li>
                            <li className="active"><a href="a"><i className="ti-angle-right"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
          </div>
        <div className="modal fade" id="modal1" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalToggleLabel">Set Quantity</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" id="myform" className="form-horizontal"  >
            <div className="modal-body" >
               <div>
                   <table >
                       <tbody className="tbodyimg">
                       <tr><td><img src={Img1} alt="" style={{width:'150px',height:'120px'}}/></td></tr>
						<b>Green Slad</b>
                      </tbody>
                  </table>
              </div>
           <div className="form-group">
              <input type="hidden" name="hotelId" id="hotelId"/ >
              <input type="hidden" name="itemId" id="itemId" />
              <input type="hidden" name="event" value="addToCart"/>
           </div>
            
           <div className="form-group">
           <h5 id="itemName2"> </h5>
           <h5 >Price :<strong id="itemPrice"></strong></h5>
           <input type="hidden" name="unitprice" id="unitprice" value=""/>
              <label for="" >
                  <b>Quantity</b>
              </label>
              <div >
                  <input type="number" name="qty" id="qty" className="form-control" min="1" value="1"/>
              </div>			
          </div>
      </div>
          <div className="modal-footer text-center ">
                <button type="submit" className="btn btn-primary btn-lg" data-bs-toggle="modal" data-bs-dismiss="modal"><i className="ti-shopping-cart"></i>Add To Cart</button>
          </div>
       </form>
          </div>
        </div>
      </div>
      </>
    );
  
}