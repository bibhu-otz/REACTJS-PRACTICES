import RegisterComponent from "../../Components/User/RegisterComponent";
const Register = () => {
  return (
    <div>
      <RegisterComponent />
    </div>
  );
};

export default Register;