import img1 from '../../Components/Images/5.jpg'
import Img2 from '../../Components/Images/11.jpg'
import { Link } from "react-router-dom";
export default function Home() {
    return (
        <div>
            <div className="slider-area">
                <div className="slider-active-2">
                    <div className="single-slider-4 bg-img furits-slider" style={{backgroundImage:`url(${img1})`}}>
                        <div className="container">
                            <div className="fadeinup-animated furits-content text-center">
                               
                                <p className="animated">Health is not about the weight you lose. But about the life you gain!</p>
                                <Link className="furits-slider-btn btn-hover animated" to="/productlist">Order Now</Link>
                                <img className="animated slide-img-position" src={Img2} alt=""/>
                            </div>
                        </div>
                    </div>
                
                </div>
                {/* <div className="slider-social">
                    <span>Follow us on:  </span>
                    <ul>
                        <li><a href="a"><i className="ti-facebook"></i></a></li>
                        <li><a href="a"><i className="ti-twitter-alt"></i></a></li>
                        <li><a href="a"><i className="ti-pinterest"></i></a></li>
                    </ul>
                </div> */}
            </div>
            <div className="container">
                    <div className="section-title-10 text-center mb-65">
                        <h2>Our Hotels</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text </p>
                    </div>
            </div>	       
            <section style={{backgroundColor: '#eee'}}>
            <div className="container py-5">
                <div className="row justify-content-center mb-3" id="hotels">
    
                <div className="col-md-12 col-xl-10">
                <div className="card shadow-0 border rounded-3">
                <div className="card-body">
                <div className="row">
                <div className="col-md-12 col-lg-3 col-xl-3 mb-4 mb-lg-0">
                <div className="bg-image hover-zoom ripple rounded ripple-surface">
                <img src={img1} className="w-50 h-50" alt=""/>
                <a href="a">
                    <div className="hover-overlay">
                    <div className="mask" style={{backgroundColor:'rgba(253, 253, 253, 0.15)'}}></div></div>
                </a></div></div>
                <div className="row">
                <h2 style={{color:'green'}}>Hotel Name</h2>
                <p  className="text-truncate mb-4 mb-md-0">Hotel Description</p>
                
                </div>
                
                <div className="col-md-6 col-lg-3 col-xl-3 border-sm-start-none border-start">
                <a style={{color:'red'}} href="a">Order Now
                </a></div></div></div></div></div>
        </div>
    </div>
            </section>
        </div>
    );
}