import Img1 from '../../Components/Images/item_Images/1.jpg'
export default function Cart() {
    return(
       
        <section  style={{backgroundColor:'#eee',marginTop:'10%'}}>
		<div className="container py-5">
			<div className="row">
				<div className="col-lg-4">
					<div className="card mb-4">
						<div className="card-body text-center" id="img1">
							<img src={Img1} alt="avatar"  className="rounded-circle img-fluid" style={{width: '150px'}}/>
	    				    <h5 className="my-3">Bibhu Mohanty</h5>
						</div>
						<ul className="nav nav-tabs flex-column text-center" role="tablist">
							<li className="nav-item w-100 mb-1"><a
								className="active btn btn-outline-success w-75" data-bs-toggle="tab"
								href="#home">Change Password</a></li>
							<li className="nav-item w-100 mb-1"><a className="btn btn-outline-success w-75"
								data-bs-toggle="tab" href="#menu1">Edit</a></li>
							<li className="nav-item w-100 mb-1"><a className="btn btn-outline-success w-75"
								data-bs-toggle="tab" href="#menu2">Orders</a></li>
						</ul>

					</div>
					<div className="card mb-4 mb-lg-0">
						<div className="card-body p-0">
							<ul className="list-group list-group-flush rounded-3">
								<li
									className="list-group-item d-flex justify-content-between align-items-center p-3">
									<i className="fas fa-globe fa-lg text-warning"></i>

								</li>
							</ul>
						</div>
					</div>

				</div>
				<div className="col-lg-8">
					<div className="card mb-4">

						
						<div className="tab-content">
							<div id="home" className="container tab-pane active">
								
								<div className="col-md-12 col-12  ms-auto me-auto">
									<div className="login">
										<div className="login-form-container"
											style={{border: 'none !important'}}>
											<div className="login-form">
												<form id="validate">
													<input type="password" name="oldPass"
														placeholder="Old Password" id="oldPass" required/>
													<input type="hidden" name="event" value="changePassword"/>
													<input type="text" name="newPass"
														placeholder="New Password" id="newPass" required/>
													<input type="text" name="confirm"
														placeholder="Confirm Password" id="confirm" required/>
													<div className="button-box">
														<div className="login-toggle-btn ">
															<div className="buttonlogin">
																<button type="submit" className="default-btn ">Change
																	Password</button>
															</div>
														</div>
													</div>
												</form>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div id="menu1" className="container tab-pane fade">
								

								<div className="card-body">
									<form id="Editmyform">
										<div className="row">
											<div className="col-sm-3">
												<p className="mb-0">Full Name</p>
											</div>
											<div className="col-sm-9">
												<input type="text" name="FullName" className="text-muted mb-0"
													id="FullName" value="" required/> <input
													type="hidden" name="event" value="Edituser"/>
											</div>
										</div>
										<hr/>
										<div className="row">
											<div className="col-sm-3">
												<p className="mb-0">Email</p>
											</div>
											<div className="col-sm-9">
												<input type="email" name="email" className="text-muted mb-0"
													id="email" required/>
											</div>
										</div>
										<hr/>
										<div className="row">
											<div className="col-sm-3">
												<p className="mb-0">Phone</p>
											</div>
											<div className="col-sm-9">
												<input type="text" name="Phone" className="text-muted mb-0"
													id="Phone" required/>
											</div>
										</div>
										<hr/>

										<div className="row">
											<div className="col-sm-3">
												<p className="mb-0">Address</p>
											</div>
											<div className="col-sm-9">
												<input type="text" name="address" className="text-muted mb-0"
													id="address" required/>
											</div>
										</div>
										<div className="button-box text-align:center">
											<div className="login-toggle-btn ">
												<div className="buttonlogin">
													<button type="submit" className="default-btn ">Update</button>
												</div>
											</div>
										</div>
									</form>
								</div>

							</div>
							<div id="menu2" className="container tab-pane fade">							
								<div className="table-content table-responsive" style={{padding:'3px 3px !important'}} >
                                <table >
                                    <thead>
                                        <tr>
                                        	<th></th>                  
                                            <th>images</th>
                                            <th>Item Name</th>
                                            <th>Order Amount</th>
                                            <th>Quantity</th>
                                            <th>Date</th>
                                            <th>Invoice</th>
                                        </tr>
                                    </thead>
                                    <tbody   id="orderBody">
                                        
										<tr >	 
											<td>1</td>
											<td className="product-thumbnail"><img src="admin/assets/itemImg/" alt="" width="70" height="65"/></td>
											<td className="product-name">Green Salad</td>
											<td className="product-price-cart"><span className="amount">$ 425543</span></td>
											<td className="product-quantity">6</td>
											<td>10-03-2023</td>
										</tr>
                                       
                                    </tbody>
                                </table>
                            </div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</section>

    );
  }