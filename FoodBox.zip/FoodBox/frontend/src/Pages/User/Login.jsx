import LoginComponent from "../../Components/User/LoginComponent";

const Login = () => {
  return (
      <LoginComponent />
  );
};
export default Login;