
export default function Cart() {
return(
    <div className="checkout-area ptb-100 mt-5">
        <div className="container">
            <form id="myform" method="POST">
                <div className="row">
                    <div className="col-lg-6 col-md-12 col-12">
                    
                            <div className="checkbox-form">						
                                <h3>Billing Details</h3>
                                <div className="row">
                                    
                                    <div className="col-md-6">
                                        <div className="checkout-form-list">
                                            <label>First Name <span className="required">*</span></label>										
                                            <input type="text" name="fname" placeholder="John" required />
                                            <input type="hidden" name="event" value="PlaceOrder" />
                                            <input type="hidden" name="totalamount" id="totalamount" value="0" />
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="checkout-form-list">
                                            <label>Last Name <span className="required">*</span></label>										
                                            <input type="text" name="lname" placeholder="Doe" required/>
                                        </div>
                                    </div>
                                    <div className="col-md-12">
                                        <div className="checkout-form-list">
                                            <label>Card Number <span className="required">*</span></label>										
                                            <input type="text" name="cardnum" placeholder="1234-5678-9012" required />
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="checkout-form-list">
                                            <label>Expiry/Validity <span className="required">*</span></label>										
                                            <input type="date"  name="exDate" required/>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="checkout-form-list">
                                            <label>CVV <span className="required">*</span></label>										
                                            <input type="text" name="cvv" placeholder="8765" required />
                                        </div>
                                    </div>
                                    
                                
                                    <div className="col-md-12">
                                        <div className="checkout-form-list">
                                            <h3>Delivery Address</h3>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="checkout-form-list">
                                            <label>State / City <span className="required">*</span></label>										
                                            <input type="text" name="address"  placeholder="" required />
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="checkout-form-list">
                                            <label>Postcode / Zip <span className="required">*</span></label>										
                                            <input type="text" name="pincode" required/>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="checkout-form-list">
                                            <label>Email Address <span className="required">*</span></label>										
                                            <input type="email" name="email" required/>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="checkout-form-list">
                                            <label>Phone  <span className="required">*</span></label>										
                                            <input name="phnum" type="text" required/>
                                        </div>
                                    </div>
                                                                
                                </div>
                                                                        
                            </div>
                    </div>	
                    <div className="col-lg-6 col-md-12 col-12">
                        <div className="your-order">
                            <h3>Your order</h3>
                            <div className="your-order-table table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th className="product-name">Name</th>
                                            <th className="product-name">Price</th>
                                            <th className="product-name">Quantity</th>
                                            <th className="product-total">Total</th>
                                        </tr>							
                                    </thead>
                                    <tbody id="CheckoutItems">
                                        <tr> 
                                            <td>1</td>	    					 
                                            <td className="product-name">Green Salad</td>
                                            <td className="product-total"><span className="amount">$ 100</span></td>	    					  
                                            <td className="product-total"><span className="amount">4</span></td>
                                            <td className="product-total"><span className="amount">$ 400</span></td>	    			        
                                    </tr>
                                        
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            
                                        </tr>
                                        <tr className="order-total">
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th>Order Total</th>
                                            <td><strong><span className="amount" id="subtotal"></span></strong>
                                            </td>
                                        </tr>								
                                    </tfoot>
                                </table>
                            </div>
                            <div className="payment-method">
                                <div className="payment-accordion">
                                    <div className="panel-group" id="faq">
                                    </div>
                                    <div className="order-button-payment">
                                        <input type="submit" value="Place order" />
                                    </div>								
                                </div>
                            </div>
                                
                            </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
);
}