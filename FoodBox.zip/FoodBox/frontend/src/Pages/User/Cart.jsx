import Img1 from '../../Components/Images/item_Images/1.jpg'
export default function Cart() {
    return(
    <div className="cart-main-area pt-95 pb-100 mt-5">
    <div className="container">
        <div className="row">
            <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                
                <form action="#">
                    <div className="table-content table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th></th>                  
                                    <th>images</th>
                                    <th>Item Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th>remove</th>
                                </tr>
                            </thead>
                            <tbody id="cartBody">
                                <tr> 
                                    <td>1</td>
                                    <td className="product-thumbnail">
                                        <img src={Img1} alt="" width="70" height="65"/>    
                                    </td>
                                    <td className="product-name">Green Salad</td>
                                    <td className="product-price-cart"><span className="amount">$56465</span></td>
                                    <td className="product-quantity"> <input value="" min="1" type=""/></td>
                                    <td>$67665</td>
                                    <td className="product-remove ">
                                        <a href="a" className="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"  id="">
                                    <i className="pe-7s-close bg-danger text-white" ></i></a></td>
                                </tr>
                                <tr> 
                                    <td>1</td>
                                    <td className="product-thumbnail">
                                        <img src={Img1} alt="" width="70" height="65"/>    
                                    </td>
                                    <td className="product-name">Green Salad</td>
                                    <td className="product-price-cart"><span className="amount">$56465</span></td>
                                    <td className="product-quantity"> <input value="" min="1" type=""/></td>
                                    <td>$67665</td>
                                    <td className="product-remove ">
                                        <a href="a" className="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"  id="">
                                    <i className="pe-7s-close bg-danger text-white" ></i></a></td>
                                </tr>
                                <tr> 
                                    <td>1</td>
                                    <td className="product-thumbnail">
                                        <img src={Img1} alt="" width="70" height="65"/>    
                                    </td>
                                    <td className="product-name">Green Salad</td>
                                    <td className="product-price-cart"><span className="amount">$56465</span></td>
                                    <td className="product-quantity"> <input value="" min="1" type=""/></td>
                                    <td>$67665</td>
                                    <td className="product-remove ">
                                        <a href="a" className="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"  id="">
                                    <i className="pe-7s-close bg-danger text-white" ></i></a></td>
                                </tr>
                                <tr> 
                                    <td>1</td>
                                    <td className="product-thumbnail">
                                        <img src={Img1} alt="" width="70" height="65"/>    
                                    </td>
                                    <td className="product-name">Green Salad</td>
                                    <td className="product-price-cart"><span className="amount">$56465</span></td>
                                    <td className="product-quantity"> <input value="" min="1" type=""/></td>
                                    <td>$67665</td>
                                    <td className="product-remove ">
                                        <a href="a" className="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"  id="">
                                    <i className="pe-7s-close bg-danger text-white" ></i></a></td>
                                </tr>
                               
                            </tbody>
                        </table>
                    </div>
                    <div className="row">
                        <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div className="coupon-all">
                                <div className="coupon">
                                    <input id="coupon_code" className="input-text" name="coupon_code" value="" placeholder="Coupon code" type="text"/>
                                    <input className="button" name="apply_coupon" value="Apply coupon" type="submit"/>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-5 ms-auto">
                            <div className="cart-page-total">
                                <h2>Cart totals</h2>
                                <ul>
                                    <li >Subtotal<span id="subtotal">1111111111</span></li>
                                    <li>Total<span id="nettotal">2222222</span></li>
                                </ul>
                                <a href="Checkout.html">Proceed to checkout</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div></div>
    );


}