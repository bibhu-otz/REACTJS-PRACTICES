import {Route, Routes } from "react-router-dom";
import Home from "./Pages/User/Home";
import ProductList from "./Pages/User/ProductList";
import Checkout from "./Pages/User/Checkout";
import Login from "./Pages/User/Login";
import MyAccount from "./Pages/User/MyAccount";
import Register from "./Pages/User/Register";
// import Error from "./Pages/User/Error";
import Cart from "./Pages/User/Cart";
// import FilterPage from "./Components/User/FilterPage";
//import ProductDetail from "./Pages/User/ProductDetail";
//import Offer from "./Components/User/Offer";
//import Payment from "./Components/User/Payment";
import Index from "./Pages/Admin/Index";
export default function MainRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/productlist" element={<ProductList />} />
      <Route path="/cart" element={<Cart />} />
      <Route path="/checkout" element={<Checkout />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/myaccount" element={<MyAccount />} />
      <Route path="/admin" element={<Index/>} />
    </Routes>
  );
}
