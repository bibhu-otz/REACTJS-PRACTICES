import React, {  useState } from "react";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { loginUser } from "../../Redux/User/Auth Redux/action";

const LoginComponent = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const dispatch = useDispatch();
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email || !password) {
      return;
    }
    dispatch(loginUser(email, password)).then(() => {
      window.location.href = "/";
    });
    setEmail("");
    setPassword("");
  };

  return(
      <div className="register-area ptb-100 mb-5 mt-5">
          <div className="container-fluid">
            <h1 className="text-center">Login</h1>
            <form onSubmit={handleSubmit}>
                <div className="row">
                  <div className="col-md-12 col-12 col-lg-6 col-xl-6 ms-auto me-auto">
                    <div className="login">
                      <div className="login-form-container">
                        <div className="login-form">
                
                          <input 
                          type="text" 
                          name="username" 
                          placeholder="Username"
                          required  
                          onChange={(e) => setEmail(e.target.value)}
                          value={email}/> 
                        
                          <input 
                          type="password"
                          name="password" 
                          placeholder="Password" 
                          required 
                          onChange={(e) => setPassword(e.target.value)}
                          value={password}/> 

                          <input type="checkbox"/> <label>Remember me</label>
                          
                          <div className="button-box">
                            <div className="login-toggle-btn ">
                              <div className="buttonlogin">
                                <button type="submit" className="default-btn ">Login</button>
                                <p>
                                  Not have an account?<Link to="/register">Sign Up</Link>
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            </form>
          </div>
      </div>
    );
};

export default LoginComponent;
