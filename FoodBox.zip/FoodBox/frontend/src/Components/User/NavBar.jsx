import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import { toast } from "react-hot-toast";
export default function Navbar() {
    const [user, setUser] = useState(localStorage.getItem("token"));
    const cartItemCount=0;
    
    const navigate = useNavigate();

    const handlelogout = () => {
        localStorage.removeItem("token");
        setUser(localStorage.getItem("token"));
        toast.success("user Logout successfully")
        navigate("/");
      };
    const cartpage = () => {
    if (user) {
          navigate("/cart");
    }else {
          toast.error("Please login");
    }
   }
  return (
    <header>
    <div className="header-bottom wrapper-padding-2 res-header-sm sticker header-sticky-3 furits-header">
        <div className="container-fluid">
            <div className="header-bottom-wrapper">
                <div className="logo-2 ptb-35">
                    <a href="index.html">
                       
                        <h1 style={{color:'#0cc90f'}}>Foodbox</h1> 
                    </a>
                </div>
                <div className="menu-style-2 handicraft-menu menu-hover">
                    <nav>
                        <ul>
                            <li><Link to="/">home</Link></li>
                            <li><Link to="/productlist">Menu</Link></li>
                            <li><Link to="/cart">Cart</Link></li>
                            <li><Link to="/myaccount">MyAccount</Link> </li>
                            <li><Link to="/contact">Contact</Link></li>
                        </ul>
                    </nav>
                </div>
                <div className="furits-login-cart">
                    <div className="furits-login">
                    {user ?(
                    <ul>
                        <li><span style={{color:'green'}}>Welcome <b>Bibhu Ranjan</b></span></li>
                        <li><Link to="/" onClick={handlelogout}>Logout</Link></li>
                    </ul>):(
                    
                        <ul>
                            <li><Link to="login">Login</Link></li>
                            <li><Link to="register">Reg</Link> </li>
                        </ul>
                    )}
                 
                    </div>
                    <div className="header-cart-4 furits-cart">
                        <Link className="icon-cart" onClick={cartpage}>
                            <i className="ti-shopping-cart"></i>
                            <span className="handicraft-count" id="cartCounter">{cartItemCount}</span>
                        </Link>
                       
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="mobile-menu-area handicraft-menu d-md-block col-md-12 col-lg-12 col-12 d-lg-none d-xl-none">
                    <div className="mobile-menu">
                        <nav id="mobile-menu-active">
                            <ul className="menu-overflow">
                            <li><Link to="/">home</Link></li>
                            <li><Link to="/productlist">Menu</Link></li>
                            <li><Link to="/cart">Cart</Link></li>
                            <li><Link to="/myaccount">MyAccount</Link> </li>
                            <li><Link to="/contact">Contact</Link></li>
                            </ul>
                        </nav>							
                    </div>
                </div>
            </div>
        </div>
    </div>
    </header>
  );
}
