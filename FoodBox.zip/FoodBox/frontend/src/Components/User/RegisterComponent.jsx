import React, { useEffect, useState } from 'react';
import { Link, useNavigate} from 'react-router-dom';
import {useDispatch, useSelector} from "react-redux";
import { registerUser } from '../../Redux/User/Auth Redux/action';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const initialState={
    username:"",
    email:"",
    phone:"",
    password:"",
    confirmpassword:"",
}
const Register = () => {
    const[registeredData,setRegisteredData]=useState(initialState);
    const dispatch=useDispatch();
    const navigate=useNavigate();
    const {currentUser}=useSelector((store)=> store.AuthReducer)
    const{username,email,password,phone,confirmpassword}=registeredData;
  
    const handleChange = (e) => {
     const{name,value}=e.target;
     setRegisteredData((prev)=> {
     let res = {...prev,[name]:value};
     return res;})
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if(password!==confirmpassword){
        toast("Wrong Password",{
          position:"top-center",
          autoClose:3000,
          theme:"dark"
      });
        return;
      }
    dispatch(registerUser(username,email,password,phone))
  };
  useEffect(()=>{
    if(currentUser){
      navigate("/register");
    }
},[currentUser,navigate])
  return (
    <div className="register-area ptb-100 mb-5 mt-5">
          <div className="container-fluid">
            <h1 className="text-center">Sign Up</h1>
            <form onSubmit={handleSubmit}>
                <div className="row">
                  <div className="col-md-12 col-12 col-lg-6 col-xl-6 ms-auto me-auto">
                    <div className="login">
                      <div className="login-form-container">
                        <div className="login-form">
                
                       
              <div >
                <label>Username</label><br/>
                <input type="text" placeholder="username" name="username" onChange={handleChange} value={registeredData.username} required/>
              </div>
              <div >
                <label >Email</label><br/>
                <input type="email" placeholder="email" name="email" onChange={handleChange} value={registeredData.email} required/>
              </div>
              <div >
                <label >Phone</label><br/>
                <input type="phone" placeholder="phone" name="phone" onChange={handleChange} value={registeredData.phone} required/>
              </div>
              <div >
                <label>Password</label><br/>
                <input type="password" placeholder="at least 6 charactor" name="password" onChange={handleChange} value={registeredData.password} required/>
              </div>
              <div >
                <label>Confirm Password</label><br/>
                <input type="password" placeholder="confirm password" name="confirmpassword" onChange={handleChange} value={registeredData.confirmpassword} required/>
              </div>
                  
                            <div className="button-box">
                            <div className="login-toggle-btn ">
                              <div className="buttonlogin">
                              <button className="default-btn" type="submit">Register</button>
                                <p>Already have an account?<Link to="/login">login</Link></p>
                              </div>
                            </div>
                          </div>
                              </div>
                            </div>
                          </div>
                        </div>
                </div>   
            </form>
            <ToastContainer/>
          </div>
      </div>
  );
}
export default Register;
