// import { useNavigate } from "react-router-dom";
export default function Footer() {
//   const navigate=useNavigate()
//   const movetosignup=()=>{
//     navigate("/register")
//   }
  return (
   <div>
          <footer className="footer-area" style={{ color: 'white', backgroundColor: 'black' }}>
              <div className="footer-top-area pt-70 pb-35 wrapper-padding-5">
                  <div className="container-fluid">
                      <div className="widget-wrapper">
                          <div className="footer-widget mb-30">
                              <a href="index.html">

                                  <h1 style={{ color: '#383838' }}>Foodbox</h1>
                              </a>
                              <div className="footer-about-2">
                                  <p>There are many variations of passages of Lorem Ipsum the majority have suffered alteration in some form, by  injected humour</p>
                          </div>
                      </div>
                      <div className="footer-widget mb-30">
                          <h3 className="footer-widget-title-5">Contact Info</h3>
                          <div className="footer-info-wrapper-3">
                              <div className="footer-address-furniture">
                                  <div className="footer-info-icon3">
                                      <span>Address: </span>
                                  </div>
                                  <div className="footer-info-content3">
                                      <p>Bhubaneswar <br />BBSR-751031</p>
                                  </div>
                              </div>
                              <div className="footer-address-furniture">
                                  <div className="footer-info-icon3">
                                      <span>Phone: </span>
                                  </div>
                                  <div className="footer-info-content3">
                                      <p>+91 123456789 <br />+91 123456789</p>
                                  </div>
                              </div>
                              <div className="footer-address-furniture">
                                  <div className="footer-info-icon3">
                                      <span>E-mail: </span>
                                  </div>
                                  <div className="footer-info-content3">
                                      <p><a href="a"> bib@gmail.com</a> <br /><a href="a"> info@opentechz.com</a></p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div className="footer-widget mb-30">
                          <h3 className="footer-widget-title-5">Newsletter</h3>
                          <div className="footer-newsletter-2">
                              <p>Send us your mail or next updates</p>
                              <div id="mc_embed_signup" className="subscribe-form-5">
                                  <form action="#" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                                      <div id="mc_embed_signup_scroll" class="mc-form">
                                          <input type="email" value="" name="EMAIL" class="email" placeholder="Enter mail address" required />

                                          <div class="mc-news" aria-hidden="true"><input type="text" name="b_6bbb9b6f5827bd842d9640c82_05d85f18ef" tabindex="-1" value="" /></div>
                                          <div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button" /></div>
                                      </div>
                                  </form>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
         </div><div class="footer-bottom ptb-20 gray-bg-8">
              <div class="container">
                  <div class="row">
                      <div class="col-12 text-center">
                          <div class="copyright-furniture">
                              <p>Copyright � <a href="a">Opentechz</a> @ 2023 . All Right Reserved.</p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
        </footer>
   </div>
  );
}