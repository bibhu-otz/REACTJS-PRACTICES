import axios from "axios";
import toast from "react-hot-toast";
import {
  LOGIN_FAILURE,
  LOGIN_REQUEST,
  LOGIN_SUCCESS,
  LOGOUT_FAILURE,
  LOGOUT_REQUEST,
  LOGOUT_SUCCESS,
  REGISTER_FAILURE,
  REGISTER_REQUEST,
  REGISTER_SUCCESS,
  SET_USER,
} from "./actionTypes";

export const registerRequest = () => {
  return {
    type: REGISTER_REQUEST,
  };
};

export const registerSuccess = (user) => {
  return {
    type: REGISTER_SUCCESS,
    payload: user,
  };
};

export const registerFailure = (error) => {
  return {
    type: REGISTER_FAILURE,
    payload: error,
  };
};

export const registerUser =
  (name, email, password, phone) => async (dispatch) => {
    console.log({ name, phone, email, password });
    dispatch(registerRequest());
    return await axios
      .post("http://localhost:4000/user/register", {
        name,
        email,
        password,
        phone,
      })
      .then((response) => {
        console.log(response);
        const user = response.data;
        dispatch(registerSuccess(user));
      })
      .then(() => {
        toast.success("Account created successfully !", {
          style: {
            borderRadius: "50px",
            background: "#989898",
            color: "#ffffff",
            padding: "1rem 1.5rem",
            fontWeight: "600",
          },
        });
      })
      .catch((error) => {
        console.log(error);
        const errorMessage = error.message;
        dispatch(
          registerFailure(
            toast.error(errorMessage, {
              style: {
                borderRadius: "50px",
                background: "#989898",
                color: "#ffffff",
                padding: "1rem 1.5rem",
                fontWeight: "600",
              },
            })
          )
        );
      });
  };

export const loginRequest = () => {
  return {
    type: LOGIN_REQUEST,
  };
};
export const loginUser = (email, password) => async (dispatch) => {
  dispatch(loginRequest());
  return await axios
    .post("http://localhost:4000/user/login", {
      email,
      password,
    })
    .then((response) => {
      const user = response.data;
      dispatch(loginSuccess(user));

      localStorage.setItem("token", user);
    })
    .then(() => {
      toast.success("login successfull !", {
        style: {
          borderRadius: "50px",
          background: "#989898",
          color: "#ffffff",
          padding: "1rem 1.5rem",
          fontWeight: "600",
        },
      });
    })

    .catch((error) => {
      const errorMessage = error.message;
      dispatch(
        loginFailure(
          toast.error(errorMessage, {
            style: {
              borderRadius: "50px",
              background: "#989898",
              color: "#ffffff",
              padding: "1rem 1.5rem",
              fontWeight: "600",
            },
          })
        )
      );
    });
};
export const loginSuccess = (user) => {
  return {
    type: LOGIN_SUCCESS,
    payload: user,
  };
};

export const loginFailure = (error) => {
  return {
    type: LOGIN_FAILURE,
    payload: error,
  };
};

export const logoutRequest = () => {
  return { type: LOGOUT_REQUEST };
};

export const logoutSuccess = () => {
  return { type: LOGOUT_SUCCESS };
};

export const logoutFailure = (payload) => {
  return { type: LOGOUT_FAILURE, payload };
};

export const setUser = (payload) => {
  return {
    type: SET_USER,
    payload,
  };
};

export const logoutUser = () => (dispatch) => {
  dispatch(logoutRequest());
  // Remove JWT token from local storage
  localStorage.removeItem("token");
  dispatch(logoutSuccess());
};
