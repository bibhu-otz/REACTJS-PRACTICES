import { legacy_createStore, applyMiddleware, combineReducers } from "redux";
// import { reducer as UserCartReducer } from "./User/Cart redux/reducer.cart";
// import { reducer as AdminReducer } from "./Admin/reducer.admin";
import { reducer as AuthReducer } from "./User/Auth Redux/reducer";
import { reducer as MedicineReducer } from "./User/Medicine Redux/reducer";
import thunk from "redux-thunk";

const rootReducer = combineReducers({
  //   UserCartReducer,
  //   AdminReducer,
  AuthReducer,
  MedicineReducer,
});

export const store = legacy_createStore(rootReducer, applyMiddleware(thunk));
