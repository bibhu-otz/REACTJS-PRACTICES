import "./App.css";
import MainRoutes from "./MainRoutes";
import Navbar from "./Components/User/NavBar";
import Footer from "./Components/User/Footer";
import { Toaster } from "react-hot-toast";
function App() {
  return (
    <div className="App">
      <Navbar />
      <MainRoutes />
      <Footer />
      <Toaster />
    </div>
  );
}
export default App;
